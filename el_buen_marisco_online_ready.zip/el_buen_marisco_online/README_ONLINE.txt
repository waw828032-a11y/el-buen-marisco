EL BUEN MARISCO - VERSION LISTA PARA PUBLICAR EN RENDER

1) Suba esta carpeta a GitHub.
2) En Render cree un Web Service conectando ese repositorio.
3) Render detecta render.yaml automaticamente.
4) Use plan Starter para poder adjuntar disco persistente.
5) Al publicar, su URL quedara algo como:
   https://el-buen-marisco.onrender.com

IMPORTANTE:
- Este proyecto usa SQLite.
- En Render, SQLite necesita disco persistente para no perder datos.
- El render.yaml ya incluye un disco montado en /var/data.

Comandos clave:
- Build: pip install -r requirements.txt
- Start: gunicorn app:app
